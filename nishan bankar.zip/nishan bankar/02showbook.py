import mysql.connector as mycon
con=mycon.connect(host='localhost',user='root',password='Pass@123',database='bookstoredb')
curs=con.cursor()
try:
    curs.execute("select * from books")
    data=curs.fetchall()
    for rec in data:
       print("Showin the all of data")
       print('bookcode:',rec[0])
       print('bookname:',rec[1])
       print('category:',rec[2])
       print('author:',rec[3])
       print('publication:',rec[4])
       print('edition:',rec[5])
       print('price',rec[6])
except:
    print("not showing dat")
       
con.close()


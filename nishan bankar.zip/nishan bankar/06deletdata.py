import mysql.connector as mycon
con=mycon.connect(host='localhost',user='root',password='Pass@123',database='bookstoredb')
curs=con.cursor()
bocode=int(input("enter your book code"))
curs.execute("select  bookname,category,author, publication, edition,price from  books where  bookcode=%d"%bocode)
rec=curs.fetchone()
try:
    if rec:
          print("BookName  :%s"%rec[0])
          print("Categeory  :%s"%rec[1])
          print("Author  :%s"%rec[2])
          print("Publication  :%s"%rec[3])
          print("Edition  :%s"%rec[4])
          print("Price  :%s"%rec[5])
        
          usr=input(" If you can Deleted Data YES/NO ")
          if usr.upper()=='YES':
              curs.execute("DELETE FROM books WHERE  bookcode=%d"%(bocode))
              con.commit()
              print("Yo are Record are deleted form table")
          elif usr.upper()=='NO':
              print("record are not deleted")
          else:
              print("you Are deta are not deleted from database")
            
except:
    print("Books Not Fount")
con.close()













 
import mysql.connector as mycon
con=mycon.connect(host='localhost',user='root',password='Pass@123',database='bookstoredb')
curs=con.cursor()
try:
    bocode=int(input('enter the books code:'))
    curs.execute("select * from  books where  bookcode=%d" %bocode)
    data=curs.fetchall()

    if data: 
        boname=input('enter the books name:')
        boCat=input('enter the books Category(comedy,horror,autobiography):')
        auth=input('enter thr the books Author:')
        pub=input('enter the publication:')
        adion=input('enter the edition:')
        price=input('enter the New price:')
        curs.execute("UPDATE books SET  bookname='%s',category='%s',author='%s', publication='%s', edition='%s', price='%s' WHERE  bookcode=%d"%(boname,boCat,auth,pub,adion,price,bocode))
        con.commit()
        print("data Updated successfully")
    else:
        print("book does not exist")

except:
      print("Bookcode Is not Found")
  
con.close()


import mysql.connector as mycon
con=mycon.connect(host='localhost',user='root',password='Pass@123',database='bookstoredb')
curs=con.cursor()
bocode=int(input("enter your book code"))
curs.execute("select  bookname,category,author, publication, edition,price from  books where  bookcode=%d"%bocode)
rec=curs.fetchone()
try:
    print("BookName  :%s"%rec[0])
    print("Categeory  :%s"%rec[1])
    print("Author  :%s"%rec[2])
    print("Publication  :%s"%rec[3])
    print("Edition  :%s"%rec[4])
    print("Price  :%s"%rec[5])

except:
    print("Books Not Fount")
con.close()


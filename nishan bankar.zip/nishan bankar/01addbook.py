import mysql.connector as mycon
con=mycon.connect(host='localhost',user='root',password='Pass@123',database='bookstoredb')
curs=con.cursor()
try:
    bocode=int(input('enter the books code:'))
    boname=input('enter the books name:')
    boCat=input('enter the books Category(comedy,horror,autobiography,):')
    auth=input('enter thr the books Author:')
    pub=input('enter the publication:')
    adion=input('enter the edition:')
    price=input('enter the price:')

    curs.execute("insert into  books values(%d,'%s','%s','%s','%s','%s','%s')"%(bocode,boname,boCat,auth,pub,adion,price))
    con.commit()
    print("data inserted successfully")
except:
    print("data not successfully inserted")
con.close()
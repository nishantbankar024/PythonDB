import mysql.connector as mycon
con=mycon.connect(host='localhost',user='root',password='Pass@123',database='bookstoredb')
curs=con.cursor()
category=input("enter your book Category")
curs.execute("select bookname, author, publication,edition, price from  books where   category='%s'"%category)
rec=curs.fetchone()
try:
      print("BookName  :%s"%rec[1])
      print("Author  :%s"%rec[3])
      print("Publication  :%s"%rec[4])
      print("Edition   :%s"%rec[5])
      print("Price   :%s"%rec[6])
except:
    print("category not found")
con.close()